import TextInput from './TextArea';

export default TextInput;
