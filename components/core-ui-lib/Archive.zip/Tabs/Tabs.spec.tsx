import { render, fireEvent, screen } from '@testing-library/react';
import Tabs from './Tabs';

describe('Tabs Component', () => {
  const tabs = ['Tab 1', 'Tab 2', 'Tab 3'];

  test('renders tabs with provided labels', () => {

    tabs.forEach(tab => {
      const tabElement = screen.getByText(tab);
      expect(tabElement).toBeInTheDocument();
    });
  });

  test('switches tab content when tab is clicked', async () => {

    // Initially, only the content of the first tab should be visible
    expect(screen.queryByText('Content for Tab 1')).toBeInTheDocument();
    expect(screen.queryByText('Content for Tab 2')).not.toBeInTheDocument();
    expect(screen.queryByText('Content for Tab 3')).not.toBeInTheDocument();

    // Click on the second tab
    fireEvent.click(screen.getByText('Tab 2'));

    // Now, the content of the second tab should be visible
    expect(screen.queryByText('Content for Tab 1')).not.toBeInTheDocument();
    expect(screen.queryByText('Content for Tab 2')).toBeInTheDocument();
    expect(screen.queryByText('Content for Tab 3')).not.toBeInTheDocument();
  });

  // Add more tests as needed...
});
