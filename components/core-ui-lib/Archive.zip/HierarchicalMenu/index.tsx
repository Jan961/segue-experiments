import HierarchicalMenu from './HierarchicalMenu';

export default HierarchicalMenu;
