import DateRange from './DateRange';

export default DateRange;
